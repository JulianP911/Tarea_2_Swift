// Tarea 2 - Swift
// Julian Padilla Molina

import UIKit

enum Velocidades : Int // Enumeracion de las velocidades
{
    case Apagado = 0 // Representa la velocidad 0km
    case VelocidadBaja = 20 // Representa una velocidad de 20km por hora
    case VelocidadMedia = 50 // Representa una velocidad de 50km por hora
    case VelocidadAlta = 120 // Representa una velocidad de 120km por hora
    
    init(velocidadInicial : Velocidades) // Inicializador del velocimetro digital
    {
        self = velocidadInicial // Se le asigna self a la velocidad inicial
    }
}

class Auto // Clase que hace referenia a un auto
{
    // Atributos
    var velocidad : Velocidades // Variable que hace referencia a una enum
    
    init() // Inicializador de la clase Auto
    {
        self.velocidad = .Apagado // Se inicializa la velocidad cuando el carro esta apagado
    }
    
    // Metodos
    func cambioDeVelocidad( ) -> (actual : Int, velocidadEnCadena: String) // Retorna una tupla con la informacion de cambio de velocidad
    {
        var velocidadActual : Int
        var velocidadEnCadena : String
        
        switch velocidad {
        case .Apagado: // Case que esta apagado pasa a velocidad baja
            velocidadEnCadena = "Velocidad Baja"
            velocidadActual = velocidad.rawValue
            velocidad = .VelocidadBaja
        case .VelocidadBaja: // Case que esta en velocidad baja pasa a velocidad media
            velocidadEnCadena = "Velocidad Media"
            velocidadActual = velocidad.rawValue
            velocidad = .VelocidadMedia
        case .VelocidadMedia: // Case que esta en velocidad media pasa a velocidad alta
            velocidadEnCadena = "Velocidad Alta"
            velocidadActual = velocidad.rawValue
            velocidad = .VelocidadAlta
        case .VelocidadAlta: // Case que esta en velocidad alta pasa a velocidad media
            velocidadEnCadena = "Velocidad Media"
            velocidadActual = velocidad.rawValue
            velocidad = .VelocidadMedia
        }
        
        return(velocidadActual, velocidadEnCadena) // Retorna la informacion de la tupla conrespondiente
    }
}

var auto = Auto() // Creacion de una instancia de un carro

for _ in 1...20 // Un for de un rango de 1 a 20
{
    print(auto.cambioDeVelocidad()) // Imprime la informacion de la tupla
}
